<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from mgsdemo.mgscoder.com/html5/light/index-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Dec 2021 03:17:15 GMT -->
<head>
	<meta charset="utf-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1" />
	
	<title>Quaphtic - Create, Enhance, Deliver</title>
	<!-- set your website meta description and keywords -->
	<meta name="description" content="Add your website description here">
	<meta name="keywords" content="Add your website keywords here">
	<!-- set your website favicon icon -->
	<link href="favicon.ico" rel="icon">
	
	<!-- Bootstrap Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Font Awesome Stylesheets -->
	<link rel="stylesheet" href="css/fontawesome/all.min.css">
	
	<!-- Template Main Stylesheets -->
	<link rel="stylesheet" href="css/style-light.css" type="text/css">
</head>

<body>
	<section id="mainhome" class="overlay">
		<div class="overlay-content">
			<div class="content">
				<div class="container"> 
                    <div class="right">
                        <img src="images/Logo.png" width="70%"/>
                    </div>
					<!-- coming-soon header text start -->
					<div class="coming-soon-text">
						<h4>We are</h4>
						<h1 font style="color: #f83a2d">coming soon</h1>
						<div class="fullwidth-box-text">
							<p>Our website is under construction, we are working very hard to give you the best experience with this one. </p>
						</div>
					</div>
					<!-- coming-soon header text end -->
					
					
					
					<!-- Start Social media -->
					<div class="social-holder">
						<ul class="list-inline list-social clearfix">
							<li>
								<a href="#" class="social-icon social-icon-facebook" target="_blank">
									<i class="fab fa-facebook-f"></i>
								</a>
							</li>
							<li>
								<a href="#" class="social-icon social-icon-twitter" target="_blank">
									<i class="fab fa-twitter"></i>
								</a>
							</li>
							<li>
								<a href="#" class="social-icon social-icon-linkedin" target="_blank">
									<i class="fab fa-linkedin-in"></i>
								</a>
							</li>
							<li>
								<a href="#" class="social-icon social-icon-youtube" target="_blank">
									<i class="fab fa-youtube"></i>
								</a>
							</li>
						</ul>
					</div>
					<!-- End Social media -->
					
					<div class="copyright text-center">&copy; <span id="mgsYear"></span> <a href="#" class="footer-site-link">Quaphtic Service Limited</a> All rights reserved.</div>
					
				</div><!-- End container -->
			</div>
		</div><!-- End of overlay-content -->
	</section><!-- End of #mainhome -->
	
	
	
	
	
	
	
	
	
	<!-- jQuery Library -->
	<script src="js/jquery-3.5.1.min.js"></script>
	<!-- countdown Js -->	
	<script src="js/jquery.plugin.min.js"></script>
	<script src="js/jquery.countdown.js"></script>
	<!-- ajaxchimp Js -->
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<!-- Form validator Js -->
	<script src="js/validator.min.js"></script>
	<!-- Template main Js -->
    <script src="js/main-light-new.js"></script>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-93541536-2', 'auto');
	  ga('send', 'pageview');

	</script>
								
</body>

<!-- Mirrored from mgsdemo.mgscoder.com/html5/light/index-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Dec 2021 03:17:26 GMT -->
</html><?php /**PATH C:\xampp\htdocs\quaphtic\resources\views/pages/index.blade.php ENDPATH**/ ?>